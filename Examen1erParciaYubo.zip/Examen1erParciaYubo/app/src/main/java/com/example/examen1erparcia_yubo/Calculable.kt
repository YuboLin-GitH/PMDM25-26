package com.example.examen1erparcia_yubo


// parte interface de Calculable
interface Calculable {
        fun calcularTotal(): Double

}