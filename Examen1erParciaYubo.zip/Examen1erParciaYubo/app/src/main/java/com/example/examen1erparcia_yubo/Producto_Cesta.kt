package com.example.examen1erparcia_yubo



// enum TipoProducto
enum class TipoProducto {
    COMIDA, BEBIDA, LIMPIEZA_HIGIENE, OTROS
}


// clase de tipo data
data class Producto_Cesta(
    val nombre: String,
    val tipo: TipoProducto,
    val precio: Double
)





